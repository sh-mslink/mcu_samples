# hello
hello world for rt-thread

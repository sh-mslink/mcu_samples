# cJSON
Ultralightweight JSON parser in ANSI C
